// Pure "connected group" finder. Given candidate items (cand:true) plus same-sized non-clickable peers
// (cand:false), return N candidates that sit next to each other in one straight run with nothing between them.
// The run direction is worked out locally from each seat's nearest neighbours, so rows can be horizontal,
// vertical or diagonal, and slightly uneven positions are fine. Seats of a row sit closer together than rows
// sit to each other. A run that is exactly N long wins over carving N out of a longer one.
(function (g) {
  const median = (a) => {
    if (!a.length) return 0;
    const s = [...a].sort((x, y) => x - y), m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  };
  const R = Math.PI / 180;
  const angDiff = (a, b) => { let d = Math.abs(a - b) % Math.PI; if (d > Math.PI / 2) d = Math.PI - d; return d; };

  function pick(raw, N, P) {
    // overlapping twins (e.g. a seat and its hit-area) count once; a clickable one wins over a plain one
    const items = [];
    for (const it of raw) {
      const S = Math.max(it.w, it.h) * 0.35;
      const j = items.findIndex((o) => Math.hypot(o.x - it.x, o.y - it.y) < S);
      if (j < 0) items.push(it);
      else if (it.cand && !items[j].cand) items[j] = it;
    }
    const C = items.filter((i) => i.cand);
    if (!C.length) return null;
    const tol = Math.max(4, median(C.map((c) => Math.max(c.w, c.h))) * P.tol);
    const order = (a, b) => (Math.abs(a.y - b.y) > tol ? a.y - b.y : a.x - b.x);
    if (N <= 1) return [C.slice().sort(order)[0]];
    const E = items;
    if (E.length < 2 || E.length > 900) return null;

    // local row axis per item (an axis, not an arrow: direction only matters modulo 180 degrees)
    const phi = new Map();
    for (const a of E) {
      const ds = [];
      for (const b of E) if (b !== a) ds.push({ b, d: Math.hypot(b.x - a.x, b.y - a.y) });
      ds.sort((p, q) => p.d - q.d);
      const near = ds[0].d;
      let sc = 0, ss = 0, cnt = 0;
      for (const o of ds) {
        if (o.d > near * P.vote || cnt >= 4) break;
        const th = Math.atan2(o.b.y - a.y, o.b.x - a.x);
        sc += Math.cos(2 * th); ss += Math.sin(2 * th); cnt++;
      }
      let ang = 0.5 * Math.atan2(ss, sc);
      if (cnt > 1 && Math.hypot(sc, ss) / cnt < 0.5) ang = Math.atan2(ds[0].b.y - a.y, ds[0].b.x - a.x); // ambiguous: trust the nearest
      phi.set(a, ang);
    }

    // nearest item on each side along the axis
    const cosA = Math.cos(P.ang * R);
    const look = (a, sign) => {
      const t = phi.get(a), ux = Math.cos(t) * sign, uy = Math.sin(t) * sign;
      let best = null, bd = Infinity;
      for (const b of E) {
        if (b === a) continue;
        const vx = b.x - a.x, vy = b.y - a.y, d = Math.hypot(vx, vy);
        if (d >= bd || (vx * ux + vy * uy) / d < cosA) continue;
        bd = d; best = b;
      }
      return best ? { b: best, d: bd } : null;
    };
    const side = new Map();
    for (const a of E) side.set(a, [look(a, 1), look(a, -1)]);
    const has = (a, b) => side.get(a).some((s) => s && s.b === b);

    // undirected neighbour links: both items must name each other and agree on the axis
    let id = 0;
    for (const e of E) e.__id = id++;
    const all = [], seen = new Set();
    for (const a of E) {
      for (const s of side.get(a)) {
        if (!s || !has(s.b, a)) continue;
        if (angDiff(phi.get(a), phi.get(s.b)) > P.cons * R) continue;
        const k = Math.min(a.__id, s.b.__id) + ':' + Math.max(a.__id, s.b.__id);
        if (seen.has(k)) continue;
        seen.add(k);
        all.push({ a, b: s.b, d: s.d });
      }
    }
    const m = median(all.map((e) => e.d));
    const adj = new Map();
    for (const e of all) {
      if (!(e.a.cand && e.b.cand && e.d <= P.span * m)) continue;
      if (!adj.has(e.a)) adj.set(e.a, []);
      if (!adj.has(e.b)) adj.set(e.b, []);
      adj.get(e.a).push(e.b); adj.get(e.b).push(e.a);
    }

    // straight runs = paths in that graph; start from each end
    const runs = [], used = new Set();
    for (const s of C) {
      const nb = adj.get(s);
      if (!nb || nb.length !== 1 || used.has(s)) continue;
      const run = [s]; used.add(s);
      let prev = s, cur = nb[0];
      while (cur) {
        run.push(cur); used.add(cur);
        const nx = (adj.get(cur) || []).filter((x) => x !== prev);
        prev = cur; cur = nx.length === 1 ? nx[0] : null;
      }
      if (order(run[0], run[run.length - 1]) > 0) run.reverse(); // read from the upper/left end
      if (run.length >= N) runs.push(run);
    }
    if (!runs.length) return null;
    runs.sort((p, q) => (p.length - q.length) || order(p[0], q[0])); // exact fit first, then reading order
    return runs[0].slice(0, N);
  }
  g.__carterPick = pick;
})(typeof window !== 'undefined' ? window : globalThis);
