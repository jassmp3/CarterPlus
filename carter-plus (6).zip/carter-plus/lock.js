// Lock screen. The key itself is never stored: a slow key derivation (PBKDF2, 300k rounds) feeds AES-GCM,
// and the only thing in the files is a sealed canary that opens when the derived key is right.
(() => {
  'use strict';
  const V = self.__CV;
  const $ = (id) => document.getElementById(id);
  const lock = $('lock'), card = $('card'), input = $('key'), go = $('go'), msg = $('msg'), lk = $('lk'), pad = $('padlock');
  const u8 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const b64 = (u) => btoa(String.fromCharCode(...u));
  const pick = (arr, last) => { let x; do { x = arr[(Math.random() * arr.length) | 0]; } while (x === last && arr.length > 1); return x; };

  async function opens(raw) {
    try {
      const k = await crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['decrypt']);
      const d = u8(V.k);
      const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: d.slice(0, 12) }, k, d.slice(12));
      return new TextDecoder().decode(pt) === 'carter-ok';
    } catch (_) { return false; }
  }
  async function derive(pw) {
    const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw.trim().toUpperCase()), 'PBKDF2', false, ['deriveBits']);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: u8(V.s), iterations: V.i, hash: 'SHA-256' }, km, 256));
  }

  const WRONG = [
    'hii imposter, good try',
    'get a life dude, dont try hard',
    'dont know the key? aww....why not build one by yourself?',
    'nope. not even close. cute attempt though.',
    'brute force? in this economy?',
    'access denied. confidence: 100%. correctness: 0%.',
    'wrong key. the fire is judging you.',
    'imposter detected. emotional damage: critical.',
    'sorry, this tool has trust issues.',
    'try again... or touch grass. your call.',
    'even the blob is laughing at you.',
    'that key belongs to someone cooler than you.'
  ];
  const RIGHT = [
    'hii, welcome... you have the total access now',
    'who told you the key? ...anyways, welcome.',
    'ohh you remembered? respect. come on in.',
    'access granted. the fire missed you.',
    'welcome, boss. warming things up...'
  ];

  // ---- cipher rain ----
  const cv = $('cipher'), g = cv.getContext('2d');
  const CW = 340, CH = 440, FS = 13, cols = Math.floor(CW / FS);
  cv.width = CW; cv.height = CH;
  const drops = Array.from({ length: cols }, () => Math.random() * CH / FS);
  const GL = '01ABCDEF#$%&*+=<>{}[]/\\|';
  let rainSpeed = 0.35, raf = 0;
  function rain() {
    g.fillStyle = 'rgba(20,2,4,.16)'; g.fillRect(0, 0, CW, CH);
    g.font = FS + 'px ui-monospace, Consolas, monospace';
    for (let i = 0; i < cols; i++) {
      const y = drops[i] * FS;
      g.fillStyle = Math.random() < 0.06 ? 'rgba(255,200,170,.9)' : 'rgba(255,60,40,.55)';
      g.fillText(GL[(Math.random() * GL.length) | 0], i * FS, y);
      drops[i] += rainSpeed * (0.6 + (i % 5) * 0.2);
      if (y > CH && Math.random() > 0.975) drops[i] = 0;
    }
    raf = requestAnimationFrame(rain);
  }

  // ---- state / cooldown ----
  let busy = false, last = null, st = { fails: 0, lockUntil: 0 }, cdTimer = 0;
  const save = () => chrome.storage.local.set({ fails: st.fails, lockUntil: st.lockUntil });
  function cooldownTick() {
    const left = Math.ceil((st.lockUntil - Date.now()) / 1000);
    if (left > 0) { input.disabled = true; go.disabled = true; if (left > 3) msg.textContent = 'too many tries. locked for ' + left + 's'; cdTimer = setTimeout(cooldownTick, 500); }
    else { input.disabled = false; go.disabled = false; busy = false; input.focus(); }
  }

  async function submit() {
    if (busy || Date.now() < st.lockUntil) return;
    const v = input.value;
    if (!v.trim()) { lk.classList.remove('bad'); void lk.offsetWidth; lk.classList.add('bad'); return; }
    busy = true; input.disabled = true; go.disabled = true; msg.className = 'msg'; msg.textContent = 'decrypting...'; rainSpeed = 1.4;
    const dk = await derive(v);
    if (await opens(dk)) {
      st = { fails: 0, lockUntil: 0 };
      chrome.storage.local.set({ dk: b64(dk), fails: 0, lockUntil: 0 });
      input.value = '';
      pad.classList.add('open'); rainSpeed = 0.15;
      msg.className = 'msg good'; msg.textContent = pick(RIGHT);
      setTimeout(() => { msg.textContent += '  [ opening... ]'; }, 1500);
      setTimeout(() => {
        lock.style.transition = 'opacity .4s'; lock.style.opacity = '0';
        setTimeout(() => { cancelAnimationFrame(raf); enter(); }, 420);
      }, 3300);
    } else {
      st.fails++;
      const wait = st.fails >= 5 ? Math.min(300, 30 * (st.fails - 4)) * 1000 : 1200;
      st.lockUntil = Date.now() + wait; save();
      last = pick(WRONG, last); msg.textContent = last;
      input.value = ''; rainSpeed = 0.35;
      lk.classList.remove('bad'); void lk.offsetWidth; lk.classList.add('bad');
      cooldownTick();
    }
  }
  go.addEventListener('click', submit);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });

  function enter() {
    lock.hidden = true;
    card.hidden = false;
    card.style.visibility = 'hidden'; // revealed by the app once its state is loaded
    window.__startApp();
  }

  chrome.storage.local.get({ dk: null, fails: 0, lockUntil: 0 }, async (r) => {
    if (r.dk && (await opens(u8(r.dk)))) { enter(); return; }
    st = { fails: r.fails || 0, lockUntil: r.lockUntil || 0 };
    lock.hidden = false;
    rain();
    input.focus();
    if (Date.now() < st.lockUntil) { busy = true; cooldownTick(); }
  });
})();
