window.__startApp = () => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const rand = (a, b) => a + Math.random() * (b - a);
  const shuffle = (arr) => { for (let i = arr.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; };
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  let resetting = false;
  // ---------- settings ----------
  const DEF = { enabled: true, sel: 1, clicks: 1, delay: 10 };
  const DELAYS = [1, 5, 10, 25, 50, 100, 200, 400, 700, 1000];
  let S = { ...DEF };
  const card = $('card'), stage = $('stage'), power = $('power');
  const save = () => chrome.storage.local.set({ enabled: S.enabled, sel: S.sel, clicks: S.clicks, delay: S.delay });
  function render() {
    $('selVal').textContent = S.sel;
    $('clicksVal').textContent = S.clicks;
    $('delayVal').textContent = S.delay;
    power.checked = S.enabled;
  }
  const bump = (btn) => { btn.classList.remove('bump'); void btn.offsetWidth; btn.classList.add('bump'); };
  const shake = (el) => { el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); };

  $('selBtn').addEventListener('click', () => { S.sel = S.sel >= 10 ? 1 : S.sel + 1; save(); render(); bump($('selBtn')); });
  $('clicksBtn').addEventListener('click', () => { S.clicks = S.clicks >= 8 ? 1 : S.clicks + 1; save(); render(); bump($('clicksBtn')); });
  $('delayBtn').addEventListener('click', () => {
    const i = DELAYS.indexOf(S.delay);
    S.delay = DELAYS[(i + 1) % DELAYS.length];
    save(); render(); bump($('delayBtn'));
  });

  // ---------- talking to the page ----------
  async function activeTab() { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); return t && t.id; }
  async function sendTop(msg) {
    try { const id = await activeTab(); return await chrome.tabs.sendMessage(id, msg, { frameId: 0 }); } catch (_) { return null; }
  }
  async function sendAll(msg) {
    try { const id = await activeTab(); await chrome.tabs.sendMessage(id, msg); } catch (_) {}
  }
  const setCount = (n) => { $('ptrCount').textContent = n + '/8'; };
  $('addBtn').addEventListener('click', async () => {
    const r = await sendTop({ type: 'addPointer' });
    if (r && typeof r.count === 'number') { const before = +$('ptrCount').textContent.split('/')[0]; setCount(r.count); if (r.count === before) shake($('addBtn')); }
    else shake($('addBtn'));
  });
  $('clrBtn').addEventListener('click', async () => { await sendTop({ type: 'clearPointers' }); setCount(0); });

  $('selReset').addEventListener('click', () => {
    const b = $('selReset'); b.classList.remove('spin'); void b.offsetWidth; b.classList.add('spin');
    sendAll({ type: 'clearSelection' });
  });

  // ---------- fire canvas ----------
  const cv = $('fire'), g = cv.getContext('2d');
  const W = 320, H = 185, CX = 160, CY = 118, R = 48; // canvas extends 20px above the stage so flames and smoke never clip
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  cv.width = W * dpr; cv.height = H * dpr; g.scale(dpr, dpr);
  const cv2 = $('fire2'), g2 = cv2.getContext('2d');
  cv2.width = W * dpr; cv2.height = H * dpr; g2.scale(dpr, dpr);
  let G = []; // low flames that lick up the front of the ball
  const heatEl = $('heat'), rimEl = $('rimglow');
  let P = [], heat = 0, boost = 1, lit = false, smokeQ = 0, smokeAcc = 0, tick = 0;
  const sm = $('smoke'), sg = sm.getContext('2d');
  let SW = 0, SH = 0, fumes = [];
  function sizeFumes() {
    SW = card.clientWidth; SH = card.clientHeight;
    sm.width = SW * dpr; sm.height = SH * dpr; sg.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function drawFumes(dt, hb) {
    if (!SW) return;
    let n = hb * 0.2 * dt;
    while (n > 0) {
      if (Math.random() < Math.min(1, n)) fumes.push({ x: rand(-10, SW + 10), y: SH + 30, s: rand(34, 82), vx: rand(-0.12, 0.12), vy: -rand(0.22, 0.55), l: 0, m: rand(300, 480), ph: rand(0, 6.28) });
      n--;
    }
    if (fumes.length > 90) fumes.splice(0, fumes.length - 90);
    sg.clearRect(0, 0, SW, SH);
    const k = Math.min(1, hb);
    const alive = [];
    for (const f of fumes) {
      f.l += dt; const t = f.l / f.m;
      if (t >= 1) continue;
      alive.push(f);
      f.x += (f.vx + Math.sin(tick * 0.02 + f.ph) * 0.12) * dt; f.y += f.vy * dt;
      const r = f.s * (1 + t * 1.3), a = 0.30 * Math.min(1, t * 6) * (1 - t) * k;
      if (a < 0.004) continue;
      const gr = sg.createRadialGradient(f.x, f.y, 0, f.x, f.y, r);
      gr.addColorStop(0, `rgba(0,0,0,${a})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
      sg.fillStyle = gr; sg.beginPath(); sg.arc(f.x, f.y, r, 0, 6.2832); sg.fill();
    }
    fumes = alive;
  }
  let dull = false;
  function setDull(v) {
    if (v === dull) return;
    dull = v;
    card.classList.toggle('off', v);
    document.documentElement.classList.toggle('off', v);
  }

  const mix = (a, b, t) => a + (b - a) * t;
  function fireCol(t) {
    if (t < 0.3) { const k = t / 0.3; return [255, mix(235, 150, k), mix(170, 40, k)]; }
    if (t < 0.65) { const k = (t - 0.3) / 0.35; return [255, mix(150, 60, k), mix(40, 14, k)]; }
    const k = (t - 0.65) / 0.35; return [mix(255, 160, k), mix(60, 18, k), mix(14, 8, k)];
  }
  function flame(burst) {
    const th = (Math.random() + Math.random() - 1) * Math.PI * 0.92, sx = Math.sin(th), c = Math.cos(th);
    P.push({ k: 'f', x: CX + sx * R * 0.92, y: CY - c * R * 0.92, vx: sx * rand(0.15, 0.5) + rand(-0.12, 0.12),
      vy: -rand(0.6, 1.35) * (burst ? 1.7 : 1) - Math.max(0, c) * 0.25, l: 0, m: rand(30, 58), s: rand(10, 19) * (burst ? 1.25 : 1), ph: rand(0, 6.28) });
  }
  function ember(burst) {
    const th = rand(-Math.PI * 0.9, Math.PI * 0.9);
    P.push({ k: 'e', x: CX + Math.sin(th) * R, y: CY - Math.cos(th) * R, vx: rand(-0.4, 0.4) * (burst ? 2.2 : 1), vy: -rand(0.4, 1.2) * (burst ? 1.8 : 1),
      l: 0, m: rand(60, 130), s: rand(1.1, 2.6), ph: rand(0, 6.28) });
  }
  function lick() {
    const f = rand(-1.25, 1.25);
    G.push({ x: CX + Math.sin(f) * R * 0.97, y: CY + Math.cos(f) * R * 0.97 - 2, vx: Math.sin(f) * 0.25 + rand(-0.15, 0.15), vy: -rand(0.5, 1.0), l: 0, m: rand(16, 30), s: rand(8, 14), ph: rand(0, 6.28) });
  }
  function smoke() {
    P.push({ k: 's', x: CX + rand(-R * 0.7, R * 0.7), y: CY - R * 0.85 + rand(-4, 10), vx: rand(-0.25, 0.25), vy: -rand(0.3, 0.75), l: 0, m: rand(70, 120), s: rand(9, 16) });
  }
  function darkBurst() {
    for (let i = 0; i < 44; i++) {
      const a = rand(0, Math.PI * 2), sp = rand(1.1, 3.6);
      P.push({ k: 'd', x: CX + Math.cos(a) * R * 0.9, y: CY + Math.sin(a) * R * 0.9, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, l: 0, m: rand(34, 58), s: rand(9, 18) });
    }
  }
  function setLit(v) { lit = v; card.classList.toggle('lit', v); stage.classList.toggle('lit', v); }
  function ignite() { boost = 2.1; setLit(true); smokeQ += 7; for (let i = 0; i < 30; i++) ember(true); for (let i = 0; i < 16; i++) flame(true); for (let i = 0; i < 10; i++) lick(); }
  function extinguish() {
    setLit(false);
    for (const p of P) if (p.k === 'f') { p.m = Math.min(p.m, p.l + 8); p.vy -= 0.5; p.vx *= 2.2; }
    G = [];
    smokeQ += 28;
    for (let i = 0; i < 16; i++) ember(true);
  }

  function drawFire(dt) {
    tick += dt;
    heat += ((lit ? 1 : 0) - heat) * (lit ? 0.05 : 0.09) * dt;
    heat = Math.max(0, Math.min(1, heat));
    boost += (1 - boost) * (1 - Math.exp(-dt / 150));
    const hb = heat * boost;
    if (heat > 0.02) {
      let n = hb * 5.4 * dt;
      while (n > 0) { if (Math.random() < Math.min(1, n)) flame(); n--; }
      if (Math.random() < hb * 0.9 * dt) ember();
      let k = hb * 2.4 * dt;
      while (k > 0) { if (Math.random() < Math.min(1, k)) lick(); k--; }
    }
    if (!lit && heat < 0.05 && Math.random() < 0.025 * dt) smoke(); // idle wisps when it's out
    smokeAcc += dt;
    if (smokeQ > 0 && smokeAcc >= 3) { smokeAcc = 0; smokeQ--; smoke(); }
    if (P.length > 380) P.splice(0, P.length - 380);

    g.clearRect(0, 0, W, H);
    g.globalCompositeOperation = 'lighter';
    if (heat > 0.02) {
      const gr = g.createRadialGradient(CX, CY, R * 0.5, CX, CY, R * 1.38); // stays inside the canvas so no hard edge shows
      gr.addColorStop(0, `rgba(255,90,25,${0.6 * Math.min(1.5, hb)})`); gr.addColorStop(1, 'rgba(255,60,10,0)');
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
    }
    const alive = [];
    for (const p of P) {
      p.l += dt;
      const t = p.l / p.m;
      if (t >= 1) continue;
      alive.push(p);
      if (p.k === 'f') {
        p.x += (p.vx + Math.sin(tick * 0.15 + p.ph) * 0.25) * dt; p.y += p.vy * dt; p.vy *= 0.995;
        const r = p.s * (1 - t * 0.7), c = fireCol(t), a = Math.min(1, (1 - t) * 1.0);
        g.globalCompositeOperation = 'lighter';
        const gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
        gr.addColorStop(0, `rgba(${c[0]|0},${c[1]|0},${c[2]|0},${a})`); gr.addColorStop(1, `rgba(${c[0]|0},${c[1]|0},${c[2]|0},0)`);
        g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, r, 0, 6.2832); g.fill();
      } else if (p.k === 'e') {
        p.x += (p.vx + Math.sin(tick * 0.08 + p.ph) * 0.3) * dt; p.y += p.vy * dt; p.vy *= 0.998;
        const a = (1 - t) * (0.55 + 0.45 * Math.sin(tick * 0.4 + p.ph));
        g.globalCompositeOperation = 'lighter';
        const gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.s * 4);
        gr.addColorStop(0, `rgba(255,200,80,${a})`); gr.addColorStop(0.25, `rgba(255,150,40,${a * 0.5})`); gr.addColorStop(1, 'rgba(255,110,20,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, p.s * 4, 0, 6.2832); g.fill();
      } else if (p.k === 's') {
        p.x += p.vx * dt; p.y += p.vy * dt; p.s += 0.2 * dt;
        const a = 0.34 * (1 - t) * (t < 0.15 ? t / 0.15 : 1);
        g.globalCompositeOperation = 'source-over';
        const gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.s);
        gr.addColorStop(0, `rgba(165,165,175,${a})`); gr.addColorStop(1, 'rgba(120,120,130,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, p.s, 0, 6.2832); g.fill();
      } else { // black fire: dark core with a dim violet-red rim so it reads on black
        p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.96; p.vy *= 0.96;
        const r = p.s * (1 + t * 0.6);
        g.globalCompositeOperation = 'lighter';
        let gr = g.createRadialGradient(p.x, p.y, r * 0.3, p.x, p.y, r * 1.5);
        gr.addColorStop(0, 'rgba(150,20,70,0)'); gr.addColorStop(0.6, `rgba(150,20,70,${0.5 * (1 - t)})`); gr.addColorStop(1, 'rgba(90,10,60,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, r * 1.5, 0, 6.2832); g.fill();
        g.globalCompositeOperation = 'source-over';
        gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
        gr.addColorStop(0, `rgba(0,0,0,${0.95 * (1 - t)})`); gr.addColorStop(1, 'rgba(10,0,10,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, r, 0, 6.2832); g.fill();
      }
    }
    P = alive;
    g.globalCompositeOperation = 'source-over';
    const fl = 0.85 + 0.15 * Math.sin(tick * 0.35) + 0.08 * Math.sin(tick * 0.9);
    heatEl.setAttribute('opacity', Math.min(1, hb * fl).toFixed(3));
    rimEl.setAttribute('opacity', (Math.min(1, hb) * (0.55 + 0.3 * Math.sin(tick * 0.3))).toFixed(3));
    g2.clearRect(0, 0, W, H);
    g2.globalCompositeOperation = 'lighter';
    const aliveG = [];
    for (const p of G) {
      p.l += dt; const t = p.l / p.m;
      if (t >= 1) continue;
      aliveG.push(p);
      p.x += (p.vx + Math.sin(tick * 0.2 + p.ph) * 0.2) * dt; p.y += p.vy * dt;
      const r = p.s * (1 - t * 0.6), c = fireCol(t * 0.9), a = (1 - t) * 0.75;
      const gr2 = g2.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
      gr2.addColorStop(0, `rgba(${c[0]|0},${c[1]|0},${c[2]|0},${a})`); gr2.addColorStop(1, `rgba(${c[0]|0},${c[1]|0},${c[2]|0},0)`);
      g2.fillStyle = gr2; g2.beginPath(); g2.arc(p.x, p.y, r, 0, 6.2832); g2.fill();
    }
    G = aliveG;
    g2.globalCompositeOperation = 'source-over';
    card.style.setProperty('--heat', heat.toFixed(3));
    setDull(heat < 0.5);
    drawFumes(dt, hb);
  }

  // ---------- eyes: always sharp and angry (sleepy when off) ----------
  const KEYS = ['w', 'h', 'rot', 'c', 'slope', 'arc', 'dx', 'dy'];
  const SHAPES = {
    angry:    (s) => ({ w: 22, h: 50, rot: s * 13, c: 0.46, slope: -s * 0.95, dx: s * 1, dy: -3 }),
    rage:     (s) => ({ w: 23, h: 48, rot: s * 19, c: 0.62, slope: -s * 1.25, dx: s * 2, dy: -3 }),
    sleepy:   (s) => ({ w: 22, h: 40, rot: -s * 5, c: 0.6, slope: 0, dx: 0, dy: 8 }),
    surprise: (s) => ({ w: 25, h: 64, rot: 0, c: 0, slope: 0, dx: s * 3, dy: -4 })
  };
  const eyes = ['L', 'R'].map((k, i) => ({
    s: i ? 1 : -1, g: $('eye' + k), pill: $('pill' + k), cut: $('cut' + k),
    st: { ...SHAPES.angry(i ? 1 : -1), bm: 1 }, blinkTarget: 1
  }));
  let mode = null, modeTimer = null;
  const current = () => mode || (S.enabled ? 'angry' : 'sleepy');
  function setMode(name, ms) { mode = name; clearTimeout(modeTimer); modeTimer = setTimeout(() => { mode = null; }, ms); }

  (function scheduleBlink() {
    setTimeout(() => {
      eyes.forEach((e) => { e.blinkTarget = 0.08; });
      setTimeout(() => eyes.forEach((e) => { e.blinkTarget = 1; }), 130);
      scheduleBlink();
    }, rand(3000, 4000));
  })();

  const look = { x: 0, y: 0 }, mouse = { x: 0, y: 0, follow: false };
  const DIRS = [[0, 0], [-0.7, 0], [0.7, 0], [0, -0.6], [0, 0.6]];
  let wander = [0, 0], bag = [];
  const wanderStep = () => { if (!bag.length) bag = shuffle([0, 1, 2, 3, 4, 0]); wander = DIRS[bag.pop()]; };
  wanderStep(); setInterval(wanderStep, 2400);
  document.addEventListener('mousemove', (e) => { mouse.x = e.clientX; mouse.y = e.clientY; mouse.follow = true; });
  document.documentElement.addEventListener('mouseleave', () => { mouse.follow = false; });
  const svg = $('blob');
  function gaze() {
    if (!mouse.follow) return wander;
    const r = svg.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + (r.height * 96) / 200;
    const dx = mouse.x - cx, dy = mouse.y - cy, dist = Math.hypot(dx, dy) || 1, mag = Math.min(1, dist / 110);
    return [(dx / dist) * mag, (dy / dist) * mag];
  }
  const BASE_X = 32, BASE_Y = -2, FACE_R = 98;
  function stepEyes(dt) {
    const kLook = 1 - Math.exp(-dt / 240), kShape = 1 - Math.exp(-dt / 200), kBlink = 1 - Math.exp(-dt / 45);
    const [tx, ty] = gaze();
    look.x += (tx - look.x) * kLook; look.y += (ty - look.y) * kLook;
    const shapeFor = SHAPES[current()];
    for (const e of eyes) {
      const t = shapeFor(e.s), st = e.st;
      for (const k of KEYS) st[k] += ((t[k] || 0) - st[k]) * kShape;
      st.bm += (e.blinkTarget - st.bm) * kBlink;
      const x = e.s * BASE_X + st.dx + look.x * 36, y = BASE_Y + st.dy + look.y * 32;
      const n = Math.min(Math.hypot(x, y) / FACE_R, 0.93), cs = Math.sqrt(1 - n * n);
      const ang = (Math.atan2(y, x) * 180) / Math.PI;
      e.g.setAttribute('transform', `translate(${x.toFixed(2)} ${y.toFixed(2)}) rotate(${ang.toFixed(1)}) scale(${cs.toFixed(3)} 1) rotate(${(-ang).toFixed(1)}) rotate(${(st.rot + x * 0.12).toFixed(1)}) scale(1 ${st.bm.toFixed(3)})`);
      e.pill.setAttribute('x', (-st.w / 2).toFixed(2)); e.pill.setAttribute('y', (-st.h / 2).toFixed(2));
      e.pill.setAttribute('width', st.w.toFixed(2)); e.pill.setAttribute('height', st.h.toFixed(2));
      e.pill.setAttribute('rx', (st.w / 2).toFixed(2));
      const y0 = -st.h / 2 - 3 + st.c * (st.h + 3);
      e.cut.setAttribute('points', `-70,${(y0 - 70 * st.slope).toFixed(2)} 70,${(y0 + 70 * st.slope).toFixed(2)} 70,90 -70,90`);
    }
  }

  let last = performance.now();
  function frame(now) {
    const dt = Math.min(60, now - last); last = now;
    stepEyes(dt);
    drawFire(dt / 16.67);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // every few seconds it flares up in a fit of rage
  (function rageLoop() {
    setTimeout(() => {
      if (S.enabled && lit && !mode && !resetting) {
        setMode('rage', 520);
        for (let i = 0; i < 16; i++) flame(true);
        for (let i = 0; i < 8; i++) ember(true);
      }
      rageLoop();
    }, rand(2600, 4600));
  })();

  // poke the ball
  $('pet').addEventListener('click', () => {
    if (S.enabled && lit) { for (let i = 0; i < 22; i++) flame(true); for (let i = 0; i < 6; i++) ember(true); setMode('rage', 700); }
    else { smokeQ += 3; }
  });

  // ---------- power ----------
  power.addEventListener('change', () => {
    S.enabled = power.checked; save(); render();
    if (S.enabled) ignite(); else extinguish();
  });

  // ---------- master reset ----------
  $('master').addEventListener('click', () => {
    if (resetting) return;
    resetting = true;
    setLit(false); heat *= 0.15; P = P.filter((p) => p.k !== 'f');
    darkBurst(); setMode('surprise', 850);
    const fl = $('flash'); fl.classList.remove('go'); void fl.offsetWidth; fl.classList.add('go');
    S = { ...S, sel: DEF.sel, clicks: DEF.clicks, delay: DEF.delay };
    save(); render(); setCount(0);
    sendAll({ type: 'masterReset' });
    setTimeout(() => { if (S.enabled) ignite(); resetting = false; }, 950);
  });

  // ---------- delay test ----------
  const track = $('track'), tp = $('tp'), tlText = $('tlText'), testBtn = $('testBtn');
  let testing = false;
  testBtn.addEventListener('click', async () => {
    if (testing) return;
    testing = true; testBtn.classList.add('run');
    const shots = S.clicks, delay = S.delay;
    sendTop({ type: 'testClicks' }); // pointers on the page animate at this speed, nothing is clicked
    track.innerHTML = ''; tlText.textContent = '…';
    const planned = Math.max(1, (shots - 1) * delay), t0 = performance.now(), times = [], ticks = [];
    for (let i = 0; i < shots; i++) {
      if (i) await wait(delay);
      const t = performance.now() - t0; times.push(t);
      const el = document.createElement('i');
      el.style.left = Math.min(100, (t / planned) * 100) + '%';
      track.appendChild(el); ticks.push(el);
      tp.classList.remove('pulse'); void tp.offsetWidth; tp.classList.add('pulse');
    }
    const total = times[times.length - 1] || 1;
    ticks.forEach((el, i) => { el.style.left = (times[i] / total) * 100 + '%'; });
    tlText.textContent = `${shots} shot${shots > 1 ? 's' : ''} · ${Math.round(total)}ms`;
    testing = false; testBtn.classList.remove('run');
  });

  // ---------- notes ----------
  const NOTES = [
    'currently on fire. this is fine.',
    'sudo extinguish --maybe',
    'fast, furious, and 3 coffees past stable.',
    'i don\'t have bugs. i have crispy features.',
    'compile time: 0s. regret time: 3s.',
    'warning: do not feed the fireball semicolons.',
    'it\'s not smoke, it\'s a cached heat wave.',
    'git blame says: the ball did it.',
    '403: chill forbidden.',
    'my love language is O(1).',
    'no thoughts. only clicks.',
    'turning it off and on again also works on fire.',
    'stack overflow? i prefer stack overburn.',
    'ping: 0ms. attitude: 9000ms.',
    'hot reload, but unironically.',
    'roses are red, violets are blue, unexpected "}" on line 32.',
    'built different. built hot.',
    'latency so low it\'s basically teleportation.'
  ];
  const noteEl = $('note');
  let nBag = [];
  function nextNote(first) {
    if (!nBag.length) nBag = shuffle(NOTES.map((_, i) => i));
    const text = NOTES[nBag.pop()];
    if (first) { noteEl.textContent = text; return; }
    noteEl.classList.add('fade');
    setTimeout(() => { noteEl.textContent = text; noteEl.classList.remove('fade'); }, 500);
  }
  nextNote(true);
  setInterval(() => nextNote(false), 60000);

  // ---------- boot ----------
  chrome.storage.local.get(DEF, async (r) => {
    S = { ...DEF, ...r };
    render();
    sizeFumes();
    if (S.enabled) { setLit(true); heat = 1; } else { setLit(false); heat = 0; }
    setDull(heat < 0.5);
    card.style.setProperty('--heat', heat);
    card.style.visibility = '';
    const st = await sendTop({ type: 'getState' });
    if (st && typeof st.count === 'number') setCount(st.count);
  });
};
