importScripts('vault.js');
const V = self.__CV;
const u8 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function openVault() {
  const { dk } = await chrome.storage.local.get({ dk: null });
  if (!dk) return null; // nothing happens until the lock screen has been passed
  try {
    const key = await crypto.subtle.importKey('raw', u8(dk), 'AES-GCM', false, ['decrypt']);
    const d = u8(V.d);
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: d.slice(0, 12) }, key, d.slice(12));
    return JSON.parse(new TextDecoder().decode(pt));
  } catch (_) { return null; }
}

chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (!m) return;
  if (m.type === 'vault') { openVault().then(send); return true; }
  if (m.type === 'relayClicker' && sender.tab) {
    chrome.tabs.sendMessage(sender.tab.id, { type: 'runClicker' }, { frameId: 0 }).catch(() => {});
  }
});
