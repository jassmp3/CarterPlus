(() => {
  'use strict';
  if (window.__carterLoaded) return;
  window.__carterLoaded = true;
  let started = false;
  function ask() {
    if (started) return;
    try {
      chrome.runtime.sendMessage({ type: 'vault' }, (X) => {
        if (chrome.runtime.lastError || !X || !X.strong || started) return;
        started = true;
        engine(X);
      });
    } catch (_) {}
  }
  try {
    ask();
    chrome.storage.onChanged.addListener((ch, a) => { if (a === 'local' && ch.dk && ch.dk.newValue) ask(); });
  } catch (_) {}
  function engine(X) {

  const IS_TOP = window === window.top;
  const pick = window.__carterPick;
  const IS_MAC = /Mac|iPhone|iPad/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');
  const hasMod = (e) => (IS_MAC ? e.metaKey : e.ctrlKey);

  // ---------- settings ----------
  const DEF = { enabled: true, sel: 1, clicks: 1, delay: 10 };
  let cfg = { ...DEF };
  let epoch = 0; // bumped to abort anything in flight
  try {
    chrome.storage.local.get(DEF, (r) => { cfg = { ...DEF, ...r }; applyEnabled(); });
    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== 'local') return;
      for (const k in c) if (k in DEF) cfg[k] = c[k].newValue;
      if (c.enabled) applyEnabled();
      if (IS_TOP && c.ptrs && !draggingPtr) syncPointers(c.ptrs.newValue);
    });
  } catch (_) {}

  // ---------- timing helpers ----------
  const mc = new MessageChannel();
  let waiters = [];
  mc.port1.onmessage = () => { const w = waiters; waiters = []; w.forEach((f) => f()); };
  const yieldNow = () => new Promise((res) => { waiters.push(res); mc.port2.postMessage(0); });
  async function sleep(ms) {
    if (ms < 4) { const t = performance.now(); do { await yieldNow(); } while (performance.now() - t < ms); return; }
    return new Promise((r) => setTimeout(r, ms));
  }

  // ---------- overlay (closed shadow root so page CSS/JS can't touch it) ----------
  const CSS = X.css;
  let host = null, root = null;
  function ensureHost() {
    if (!host) {
      host = document.createElement('div');
      host.setAttribute('data-carter', '');
      host.style.cssText = 'position:absolute!important;left:0!important;top:0!important;width:0!important;height:0!important;overflow:visible!important;z-index:2147483647!important;pointer-events:none!important;margin:0!important;padding:0!important;border:0!important;';
      root = host.attachShadow({ mode: 'closed' });
      const st = document.createElement('style');
      st.textContent = CSS;
      root.appendChild(st);
    }
    if (!host.isConnected) document.documentElement.appendChild(host);
    applyVis();
  }
  function applyVis() { if (host) host.style.setProperty('display', cfg.enabled ? 'block' : 'none', 'important'); }

  const NS = 'http://www.w3.org/2000/svg';
  const svgEl = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };

  // ---------- selection box (page coordinates, stays after release) ----------
  let rect = null, box = null, armed = false, done = false, dragging = false;
  let sx = 0, sy = 0, cx = 0, cy = 0, styleEl = null, swallowUntil = 0;
  const px = (e) => e.clientX + window.scrollX;
  const py = (e) => e.clientY + window.scrollY;

  function placeBox() {
    if (!box || !rect) return;
    const s = box.style;
    s.left = rect.l + 'px'; s.top = rect.t + 'px';
    s.width = (rect.r - rect.l) + 'px'; s.height = (rect.b - rect.t) + 'px';
  }
  function clearBox() {
    epoch++; armed = false; done = false; rect = null; scanning = false;
    stopWatch();
    if (box) { box.remove(); box = null; }
  }
  function injectStyle() {
    styleEl = document.createElement('style');
    styleEl.textContent = 'html, html * { -webkit-user-select: none !important; user-select: none !important; -webkit-user-drag: none !important; }';
    (document.head || document.documentElement).appendChild(styleEl);
  }
  function removeStyle() { if (styleEl) { styleEl.remove(); styleEl = null; } }

  // ---------- drag handling ----------
  const block = (e) => { e.preventDefault(); e.stopImmediatePropagation(); };

  function onDown(e) {
    if (!e.isTrusted) return;
    if (!alive()) { teardown(); return; }
    if (dragging) { block(e); return; }
    if (!cfg.enabled || e.button !== 0 || !hasMod(e)) return;
    block(e);
    clearBox();
    ensureHost();
    dragging = true;
    sx = cx = px(e); sy = cy = py(e);
    try { document.getSelection().removeAllRanges(); } catch (_) {}
    injectStyle();
    box = document.createElement('div');
    box.className = 'box';
    root.appendChild(box);
    drawDrag();
  }
  function drawDrag() {
    rect = { l: Math.min(sx, cx), t: Math.min(sy, cy), r: Math.max(sx, cx), b: Math.max(sy, cy) };
    placeBox();
  }
  function onMove(e) {
    if (!dragging || !e.isTrusted) return;
    block(e);
    if (e.buttons === 0) { finishDrag(); return; }
    cx = px(e); cy = py(e);
    drawDrag();
  }
  function onUp(e) {
    if (!e.isTrusted) return;
    if (dragging) {
      block(e);
      if (e.button === 0) { cx = px(e); cy = py(e); finishDrag(); }
      return;
    }
    if (Date.now() < swallowUntil) block(e);
  }
  function finishDrag() {
    dragging = false;
    swallowUntil = Date.now() + 150;
    removeStyle();
    drawDrag();
    box.className = 'box armed';
    armed = true; done = false;
    startWatch();
    scan();
  }
  function cancelDrag() {
    if (!dragging) return;
    dragging = false;
    removeStyle();
    clearBox();
  }
  const onClick = (e) => { if (e.isTrusted && Date.now() < swallowUntil) block(e); };
  const onGuard = (e) => { if (dragging || Date.now() < swallowUntil) block(e); };
  const onKey = (e) => { if (dragging && e.key === 'Escape') { block(e); cancelDrag(); } };

  // track the user's own mouse use so we never fire synthetic clicks into a map they are still dragging
  let held = false, lastInput = 0;
  const track = (e) => {
    if (!e.isTrusted || dragging) return;
    const t = performance.now();
    if (e.type === 'pointerdown') { if (e.button === 0 && hasMod(e) && cfg.enabled) return; held = true; lastInput = t; }
    else if (e.type === 'pointerup' || e.type === 'pointercancel') { held = false; lastInput = t; }
    else if (e.type === 'wheel') lastInput = t;
  };
  ['pointerdown', 'pointerup', 'pointercancel', 'wheel'].forEach((t) => window.addEventListener(t, track, { capture: true, passive: true }));
  window.addEventListener('blur', () => { held = false; });

  const o = { capture: true, passive: false };
  ['pointerdown', 'mousedown'].forEach((t) => window.addEventListener(t, onDown, o));
  ['pointermove', 'mousemove'].forEach((t) => window.addEventListener(t, onMove, o));
  ['pointerup', 'mouseup'].forEach((t) => window.addEventListener(t, onUp, o));
  window.addEventListener('click', onClick, o);
  ['contextmenu', 'dragstart', 'selectstart', 'dragenter', 'dragover'].forEach((t) => window.addEventListener(t, onGuard, o));
  window.addEventListener('keydown', onKey, o);
  window.addEventListener('blur', cancelDrag);

  // After the extension is reloaded or updated, tabs that were already open keep a dead copy of this script
  // (it can no longer hear the on/off switch). Detect that and shut the copy down.
  let dead = false, aliveTimer = 0;
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; } };
  function teardown() {
    if (dead) return;
    dead = true; epoch++;
    clearInterval(aliveTimer); stopWatch(); removeStyle();
    try { if (host) host.remove(); } catch (_) {}
    ['pointerdown', 'mousedown'].forEach((t) => window.removeEventListener(t, onDown, o));
    ['pointermove', 'mousemove'].forEach((t) => window.removeEventListener(t, onMove, o));
    ['pointerup', 'mouseup'].forEach((t) => window.removeEventListener(t, onUp, o));
    window.removeEventListener('click', onClick, o);
    ['contextmenu', 'dragstart', 'selectstart', 'dragenter', 'dragover'].forEach((t) => window.removeEventListener(t, onGuard, o));
    window.removeEventListener('keydown', onKey, o);
    window.removeEventListener('blur', cancelDrag);
  }
  aliveTimer = setInterval(() => { if (!alive()) teardown(); }, 1500);

  function applyEnabled() {
    applyVis();
    if (!cfg.enabled) { epoch++; scanning = false; clickRunning = false; stopWatch(); cancelDrag(); }
    else if (rect && !done && !dragging) { armed = true; if (box) box.className = 'box armed'; startWatch(); scan(); }
  }

  // ---------- finding candidates ----------
  const STRONG = X.strong;
  const WEAK = X.weak;
  const TAKEN = new RegExp(X.taken, 'i');

  const parentOf = (el) => {
    if (el.parentElement) return el.parentElement;
    const r = el.getRootNode && el.getRootNode();
    return r && r.host ? r.host : null;
  };
  function* walk(r) {
    for (const el of r.querySelectorAll('*')) { yield el; if (el.shadowRoot) yield* walk(el.shadowRoot); }
  }
  const median = (a) => { if (!a.length) return 0; const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

  function isAvailable(el) {
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
    if (el.tagName === 'INPUT' && (el.type === 'checkbox' || el.type === 'radio') && el.checked) return false;
    for (const a of ['aria-checked', 'aria-pressed', 'aria-selected']) if (el.getAttribute(a) === 'true') return false;
    if (el.tagName === 'SUMMARY' && el.parentElement && el.parentElement.open) return false;
    const cls = el.getAttribute('class');
    if (cls && TAKEN.test(cls)) return false;
    return true;
  }

  function scanRegion(sel) {
    const vw = innerWidth, vh = innerHeight, M = 80;
    const near = [], all = new Set(), strong = new Set();
    for (const el of walk(document)) {
      if (el === host) continue;
      const rc = el.getBoundingClientRect();
      if (rc.width <= 0 || rc.height <= 0) continue;
      if (rc.right < sel.l - M || rc.left > sel.r + M || rc.bottom < sel.t - M || rc.top > sel.b + M) continue;
      near.push({ el, rc });
      if (rc.right < sel.l - 1 || rc.left > sel.r + 1 || rc.bottom < sel.t - 1 || rc.top > sel.b + 1) continue;
      const tag = el.tagName;
      if (tag === 'HTML' || tag === 'BODY') continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.pointerEvents === 'none') continue;
      const s = el.matches(STRONG);
      let w = !s && el.matches(WEAK);
      if (!s && !w) {
        if (cs.cursor !== 'pointer') continue;
        const p = parentOf(el);
        if (p && getComputedStyle(p).cursor === 'pointer') continue;
        w = true;
      }
      if (!s && rc.width * rc.height > vw * vh * 0.25) continue;
      if (!isAvailable(el)) continue;
      all.add(el);
      if (s) strong.add(el);
    }
    // wrappers around other targets, labels of targeted inputs, parts nested in real controls
    const list = [...all], hasDesc = new Set();
    for (const el of list) { let p = parentOf(el); while (p) { hasDesc.add(p); p = parentOf(p); } }
    let kept = list.filter((el) => strong.has(el) || !hasDesc.has(el));
    const ks = new Set(kept);
    kept = kept.filter((el) => {
      if (el.tagName === 'LABEL' && el.control && ks.has(el.control)) return false;
      let p = parentOf(el);
      while (p) { if (ks.has(p) && strong.has(p)) return false; p = parentOf(p); }
      return true;
    });
    const items = kept.map((el) => {
      const r = el.getBoundingClientRect();
      return { el, cand: true, x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height };
    });
    if (!items.length) return items;

    // same-sized, non-clickable neighbours (taken seats etc.) mark occupied slots
    const S = median(items.map((i) => Math.max(i.w, i.h)));
    const mw = median(items.map((i) => i.w)), mh = median(items.map((i) => i.h));
    const tags = new Set(kept.map((e) => e.tagName));
    const anySvg = kept.some((e) => e instanceof SVGElement);
    for (const { el, rc } of near) {
      if (all.has(el)) continue;
      if (rc.width < mw * 0.65 || rc.width > mw * 1.35 || rc.height < mh * 0.65 || rc.height > mh * 1.35) continue;
      if (!(tags.has(el.tagName) || (anySvg && el instanceof SVGElement))) continue;
      const x = rc.left + rc.width / 2, y = rc.top + rc.height / 2;
      if (items.some((i) => Math.hypot(i.x - x, i.y - y) < S * 0.4)) continue;
      items.push({ el, cand: false, x, y, w: rc.width, h: rc.height });
    }
    return items;
  }
  function findGroup(sel, N) {
    const items = scanRegion(sel);
    if (!items.length) return null;
    return pick(items, N, X.f);
  }

  // ---------- activating things ----------
  function press(el, x, y, mods) {
    const base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, ...(mods || {}) };
    const P = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
    const ptr = { pointerId: 1, pointerType: 'mouse', isPrimary: true };
    const hv = { ...base, buttons: 0 };
    el.dispatchEvent(new P('pointerover', { ...hv, ...ptr }));
    el.dispatchEvent(new P('pointerenter', { ...hv, ...ptr, bubbles: false }));
    el.dispatchEvent(new MouseEvent('mouseover', hv));
    el.dispatchEvent(new MouseEvent('mouseenter', { ...hv, bubbles: false }));
    el.dispatchEvent(new P('pointermove', { ...hv, ...ptr }));
    el.dispatchEvent(new MouseEvent('mousemove', hv));
    el.dispatchEvent(new P('pointerdown', { ...base, ...ptr, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...base, buttons: 1 }));
    el.dispatchEvent(new P('pointerup', { ...base, ...ptr, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mouseup', { ...base, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('click', { ...base, buttons: 0, detail: 1 }));
  }
  const isLink = (el) => el.tagName === 'A' && el.hasAttribute('href');

  // seats that are still animating in (fade, slide) often ignore clicks: wait for finite animations/transitions to end
  async function waitAnimations(els, cap) {
    const end = performance.now() + cap;
    let waited = false;
    for (;;) {
      const pending = [];
      for (const el of els) {
        let n = el;
        for (let i = 0; i < 4 && n; i++) {
          try {
            for (const a of n.getAnimations()) {
              if (a.playState !== 'running') continue;
              const it = a.effect && a.effect.getComputedTiming ? a.effect.getComputedTiming().iterations : 1;
              if (it !== Infinity) pending.push(a.finished.catch(() => {}));
            }
          } catch (_) {}
          n = n.parentElement;
        }
      }
      if (!pending.length || performance.now() >= end) return waited;
      waited = true;
      await Promise.race([Promise.all(pending), sleep(Math.max(0, end - performance.now()))]);
    }
  }

  // wait until the page has stopped changing for `quiet` ms (or `max` ms passed)
  function settle(quiet, max) {
    return new Promise((res) => {
      let fin = false, t = 0;
      const done = () => { if (fin) return; fin = true; clearTimeout(t); m.disconnect(); res(); };
      const m = new MutationObserver(() => { clearTimeout(t); t = setTimeout(done, quiet); });
      m.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
      t = setTimeout(done, quiet);
      setTimeout(done, max);
    });
  }
  function sig(el) {
    let s = (el.getAttribute('class') || '') + '|' + (el.getAttribute('aria-checked') || '') + (el.getAttribute('aria-pressed') || '') + (el.getAttribute('aria-selected') || '') + '|' + (el.checked ? 1 : 0) + '|' + el.childElementCount;
    try { const cs = getComputedStyle(el); s += '|' + cs.backgroundColor + cs.fill + cs.stroke + cs.color + cs.borderColor; } catch (_) {}
    return s;
  }
  // the page re-rendered and our element is gone: find the item that now sits at the same spot
  async function findAt(t, my) {
    for (let i = 0; i < 6; i++) {
      if (my !== epoch) return null;
      const v = viewRect();
      if (!v) return null;
      let best = null, bd = Infinity;
      for (const it of scanRegion(v)) {
        if (!it.cand) continue;
        const d = Math.hypot(it.x - t.x, it.y - t.y);
        if (d < bd) { bd = d; best = it; }
      }
      if (best && bd <= Math.max(10, t.S * 0.7)) return best.el;
      await sleep(30);
    }
    return null;
  }
  // same-spot lookup without waiting (used when the page has already redrawn our element)
  function quickFind(t) {
    const v = viewRect();
    if (!v) return null;
    let best = null, bd = Infinity;
    for (const it of scanRegion(v)) {
      if (!it.cand) continue;
      const d = Math.hypot(it.x - t.x, it.y - t.y);
      if (d < bd) { bd = d; best = it; }
    }
    return best && bd <= Math.max(10, t.S * 0.7) ? best.el : null;
  }
  const isNativeCheck = (el) => el.tagName === 'INPUT' && (el.type === 'checkbox' || el.type === 'radio');

  async function selectGroup(items, my) {
    const multiLink = items.filter((i) => isLink(i.el)).length > 1;
    const T = items.map((it) => {
      const el = it.el, tag = el.tagName, role = el.getAttribute('role');
      return {
        el, x: it.x, y: it.y, S: Math.max(it.w, it.h), again: false, before: sig(el),
        risky: tag === 'BUTTON' || tag === 'A' || (tag === 'INPUT' && /button|submit|reset/.test(el.type)) || role === 'button' || role === 'link'
      };
    });
    const fire = (t) => {
      if (!t.el.isConnected) { const f = quickFind(t); if (!f) return; t.el = f; }
      if (t.again && !isAvailable(t.el)) return;
      const r = t.el.getBoundingClientRect(), mods = {};
      if (multiLink && isLink(t.el)) { if (IS_MAC) mods.metaKey = true; else mods.ctrlKey = true; }
      try { press(t.el, r.left + r.width / 2, r.top + r.height / 2, mods); } catch (_) {}
    };
    const lost = () => T.filter((t) => {
      if (t.risky) return false; // never repeat a button or link
      if (!t.el.isConnected) { const f = quickFind(t); if (!f) return false; t.el = f; return sig(f) === t.before; }
      return sig(t.el) === t.before && isAvailable(t.el);
    });
    const allNative = T.every((t) => isNativeCheck(t.el));

    for (const t of T) { if (my !== epoch) return; fire(t); }   // all clicks back to back, no waiting between them
    if (!allNative) await settle(22, 140);                      // checkboxes update instantly, everything else gets one short look
    if (my !== epoch) return;
    let retry = lost();
    for (let round = 0; round < 3 && retry.length; round++) {
      if (!allNative && round === 0) {                           // slow pages update late: look again before calling a click lost
        await settle(70, 200);
        if (my !== epoch) return;
        retry = lost();
        if (!retry.length) return;
      }
      retry.forEach((t) => { t.again = true; if (t.el.isConnected) t.before = sig(t.el); fire(t); });
      if (!allNative) await settle(round ? 80 : 40, 180);
      if (my !== epoch) return;
      retry = lost();
    }
  }

  function vanishBox() {
    const b = box;
    box = null; rect = null; armed = false;
    if (!b) return;
    b.className = 'box flash';
    setTimeout(() => { b.style.transition = 'opacity .3s'; b.style.opacity = '0'; }, 140);
    setTimeout(() => b.remove(), 520);
  }

  // ---------- watcher: waits for N connected targets, then goes ----------
  let scanning = false, mo = null, timer = null, rafPending = false, lastScan = 0, retry = 0;
  function startWatch() {
    stopWatch();
    if (!armed || !cfg.enabled) return;
    mo = new MutationObserver(() => sched());
    mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true });
    timer = setInterval(scan, 100);
  }
  function stopWatch() {
    if (mo) { mo.disconnect(); mo = null; }
    if (timer) { clearInterval(timer); timer = null; }
  }
  function sched() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => { rafPending = false; scan(); });
  }
  function viewRect() {
    if (!rect) return null;
    const v = { l: rect.l - window.scrollX, t: rect.t - window.scrollY, r: rect.r - window.scrollX, b: rect.b - window.scrollY };
    if (v.r < 0 || v.b < 0 || v.l > innerWidth || v.t > innerHeight) return null;
    return v;
  }
  async function scan() {
    if (!armed || done || scanning || !cfg.enabled || !rect) return;
    const now = performance.now();
    if (held || now - lastInput < 140) { if (!retry) retry = setTimeout(() => { retry = 0; scan(); }, 60); return; }
    if (now - lastScan < 16) { if (!retry) retry = setTimeout(() => { retry = 0; scan(); }, 18); return; }
    lastScan = now;
    const v = viewRect();
    if (!v) return;
    let group = null;
    try { group = findGroup(v, cfg.sel); } catch (_) { return; }
    if (!group) return;

    const my = epoch;
    scanning = true; armed = false;
    stopWatch();
    await settle(6, 40); // seats often appear in a burst: wait for it to finish, then look again
    if (my !== epoch) { scanning = false; return; }
    const v2 = viewRect();
    let fresh = null;
    try { fresh = v2 ? findGroup(v2, cfg.sel) : null; } catch (_) {}
    if (!fresh) { scanning = false; armed = true; startWatch(); return; } // it vanished again: keep waiting
    if (await waitAnimations(fresh.map((i) => i.el), 500)) {
      // the page's own 'animation finished' handlers run a frame later: let them, so a seat is really ready
      await Promise.race([new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))), sleep(60)]);
    }
    if (my !== epoch) { scanning = false; return; }
    await selectGroup(fresh, my);
    if (my !== epoch) return;
    scanning = false; done = true;
    vanishBox();
    if (IS_TOP) runClicker(my); else { try { chrome.runtime.sendMessage({ type: 'relayClicker' }); } catch (_) {} }
  }

  // ---------- clicker pointers (top frame) ----------
  const pointers = [];
  let clickRunning = false, draggingPtr = false;
  const ptrKey = 'ptrs'; // one set of pointers for every page and tab, until it is reset
  function place(p) { p.el.style.left = p.x + 'px'; p.el.style.top = p.y + 'px'; }
  const snapshot = () => pointers.map((p) => ({ x: Math.round(p.x), y: Math.round(p.y) }));
  function refreshBadges() { pointers.forEach((p) => { p.badge.style.display = pointers.length > 1 ? '' : 'none'; }); }
  function savePointers() {
    if (!IS_TOP) return;
    try {
      if (pointers.length) chrome.storage.local.set({ [ptrKey]: snapshot() });
      else chrome.storage.local.remove(ptrKey);
    } catch (_) {}
  }
  function buildPointer(x, y, n) {
    const p = { x, y, el: document.createElement('div'), badge: document.createElement('b') };
    p.el.className = 'ptr';
    const svg = svgEl('svg', { viewBox: '0 0 36 36', width: 36, height: 36 });
    svg.append(
      svgEl('circle', { cx: 18, cy: 18, r: 9, fill: 'rgba(255,40,20,.12)', stroke: '#ff2a1a', 'stroke-width': 2 }),
      svgEl('path', { d: 'M18 1v9M18 26v9M1 18h9M26 18h9', stroke: '#ff2a1a', 'stroke-width': 2, 'stroke-linecap': 'round' }),
      svgEl('circle', { cx: 18, cy: 18, r: 1.8, fill: '#fff' })
    );
    p.badge.textContent = String(n);
    p.el.append(svg, p.badge);
    p.el.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault(); e.stopPropagation();
      draggingPtr = true;
      p.el.setPointerCapture(e.pointerId);
      p.el.classList.add('drag');
      const ox = p.x - px(e), oy = p.y - py(e);
      const mv = (ev) => { p.x = Math.max(0, px(ev) + ox); p.y = Math.max(0, py(ev) + oy); place(p); };
      const up = () => {
        p.el.classList.remove('drag');
        p.el.removeEventListener('pointermove', mv);
        p.el.removeEventListener('pointerup', up);
        p.el.removeEventListener('pointercancel', up);
        draggingPtr = false;
        savePointers();
      };
      p.el.addEventListener('pointermove', mv);
      p.el.addEventListener('pointerup', up);
      p.el.addEventListener('pointercancel', up);
    });
    place(p);
    root.appendChild(p.el);
    return p;
  }
  function dropDom() { for (const p of pointers) p.el.remove(); pointers.length = 0; }
  function syncPointers(arr) {
    if (!Array.isArray(arr)) arr = [];
    if (JSON.stringify(arr) === JSON.stringify(snapshot())) return;
    dropDom();
    if (arr.length) ensureHost();
    arr.slice(0, 8).forEach((q, i) => pointers.push(buildPointer(q.x, q.y, i + 1)));
    refreshBadges();
  }
  function loadPointers() {
    if (!IS_TOP) return;
    try { chrome.storage.local.get(ptrKey, (r) => syncPointers(r[ptrKey])); } catch (_) {}
  }
  function addPointer() {
    if (!IS_TOP || pointers.length >= 8) return pointers.length;
    ensureHost();
    const n = pointers.length + 1;
    pointers.push(buildPointer(window.scrollX + innerWidth / 2 + (n - 1) * 44 - 20, window.scrollY + innerHeight / 2, n));
    refreshBadges();
    savePointers();
    return pointers.length;
  }
  function clearPointers() {
    dropDom();
    clickRunning = false;
    savePointers();
  }
  if (IS_TOP) loadPointers();
  function deepAt(x, y) {
    let r = document, el = null;
    for (let i = 0; i < 6; i++) {
      const t = r.elementsFromPoint(x, y).filter((e) => e !== host)[0];
      if (!t) break;
      el = t;
      if (t.shadowRoot) r = t.shadowRoot; else break;
    }
    return el;
  }
  function flashPtr(p) { p.el.classList.remove('hit'); void p.el.offsetWidth; p.el.classList.add('hit'); }
  function clickAt(p) {
    const x = p.x - window.scrollX, y = p.y - window.scrollY;
    flashPtr(p);
    if (x < 0 || y < 0 || x > innerWidth || y > innerHeight) return;
    const t = deepAt(x, y);
    if (t) { try { press(t, x, y); } catch (_) {} }
  }
  async function runClicker(my) {
    if (!IS_TOP || clickRunning || !pointers.length) return;
    clickRunning = true;
    const rounds = cfg.clicks, delay = cfg.delay, list = [...pointers];
    let first = true;
    for (let r = 0; r < rounds; r++) {
      for (const p of list) {
        if (my !== undefined && my !== epoch) { clickRunning = false; return; }
        if (!cfg.enabled || !pointers.includes(p)) { clickRunning = false; return; }
        if (!first) await sleep(delay);
        first = false;
        clickAt(p);
      }
    }
    clickRunning = false;
  }

  // Test button: same order and timing as a real run, but only the pointers animate. Nothing is clicked.
  async function testClicker() {
    if (!IS_TOP || clickRunning || !pointers.length || !cfg.enabled) return;
    clickRunning = true;
    const rounds = cfg.clicks, delay = cfg.delay, list = [...pointers];
    let first = true;
    for (let r = 0; r < rounds; r++) {
      for (const p of list) {
        if (!cfg.enabled || !pointers.includes(p)) { clickRunning = false; return; }
        if (!first) await sleep(delay);
        first = false;
        flashPtr(p);
      }
    }
    clickRunning = false;
  }

  // ---------- messages from popup / background ----------
  chrome.runtime.onMessage.addListener((m, _s, send) => {
    switch (m && m.type) {
      case 'addPointer': if (IS_TOP) send({ count: addPointer() }); break;
      case 'clearPointers': if (IS_TOP) { clearPointers(); send({ count: 0 }); } break;
      case 'getState': if (IS_TOP) send({ count: pointers.length, box: !!rect }); break;
      case 'masterReset': clearBox(); if (IS_TOP) clearPointers(); break;
      case 'runClicker': if (IS_TOP) runClicker(); break;
      case 'clearSelection': clearBox(); break;
      case 'testClicks': if (IS_TOP) testClicker(); break;
    }
  });
}
})();
